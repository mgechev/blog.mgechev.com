Thanks for downloading BlackPower free wordpress theme.

please post as a comment in http://www.skinpress.com/blackpower-theme/ for support related queries.

Thanks

http://www.skinpress.com