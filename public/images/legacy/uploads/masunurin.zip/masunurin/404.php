<?php get_header(); ?>

<div id="content">
	<div class="post">
		<div class="top"></div>
		<div class="mid">
			<div class="title">
				<h2>No Page Found</h2>
			</div>
			<div class="entry errorentry">
				<p>Sorry, but you are looking for a page that isn't here.</p>
			</div>
		</div>
		<div class="bot"></div>
	</div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>