<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title>
<?php if ( is_home() ) { ?><? bloginfo('name'); ?> | <?php bloginfo('description'); ?><?php } ?>

<?php if ( is_search() ) { ?>Search Results for <?php /* Search Count */ $allsearch = &new WP_Query("s=$s&showposts=-1"); $key = wp_specialchars($s, 1); $count = $allsearch->post_count; _e(''); echo $key; _e(' � '); echo $count . ' '; _e('articles'); wp_reset_query(); ?><?php } ?>

<?php if ( is_404() ) { ?><? bloginfo('name'); ?> | 404 Nothing Found<?php } ?>

<?php if ( is_author() ) { ?><? bloginfo('name'); ?> | Author Archives<?php } ?>

<?php if ( is_single() ) { ?><?php wp_title(''); ?> | <?php $category = get_the_category(); echo $category[0]->cat_name; ?><?php } ?>

<?php if ( is_page() ) { ?><? bloginfo('name'); ?> | <?php wp_title(''); ?><?php } ?>

<?php if ( is_category() ) { ?><?php single_cat_title(); ?> <?php } ?>

<?php if ( is_month() ) { ?><? bloginfo('name'); ?> | Archive | <?php the_time('F, Y'); ?><?php } ?>

<?php if ( is_day() ) { ?><? bloginfo('name'); ?> | Archive | <?php the_time('F j, Y'); ?><?php } ?>

<?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><?php single_tag_title("", true); } } ?> | <? bloginfo('name'); ?>
</title>
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<?php wp_head(); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/mootools.1.2.1.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/mootools.1.2.1.more.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.validate.min.js"></script>
<!--[if IE]>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style-browser-ie.css" type="text/css" media="screen" />
<![endif]-->
<script type="text/javascript">
//<!--
/* <![CDATA[ */


function hookSearchInput() {
	var input = $('s');
	input.addEvents({
		'focus': function () {
			if (input.value == 'Search the blog') { input.value = ''; }
		},
		'blur': function () {
			if (input.value == '') { input.value = 'Search the blog'; }
		}
	});
}

function setEvenList() {
	var lastchild = $$('div#navmenu-wrapper ul > li:last-child a'); 
	if (null != lastchild) {
		lastchild.each(function(li) {
			li.setStyle('background','transparent none');
		});
	}
	
	var lastchild = $$('div.box-twitter div.interior ul li:last-child span'); 
	if (null != lastchild) {
		lastchild.each(function(li) {
			li.setStyle('background','transparent none');
		});
	}

	var lastchild = $$('div.box div.interior ul > li:last-child'); 
	if (null != lastchild) {
		lastchild.each(function(li) {
			li.setStyle('background','transparent none');
		});
	}
	
}

window.addEvent('domready',function () {
	hookSearchInput();
	setEvenList();

});
/* ]]> */
//-->
</script>
<script type="text/javascript">
$jquery = jQuery.noConflict();
$jquery().ready(function() {
// validate the comment form when it is submitted
$jquery("#commentform").validate();
});
</script>
</head>

<body>
<div id="container">

	<div id="nav-container">
    	<div id="nav-container-wrapper">
            <div id="navmenu">	
                <div id="navmenu-wrapper">
                    
                    <ul>
                        <?php themefunction_page_menu(); ?>
                    </ul>                       
                 </div>           				
            </div>
        		<?  
			  	$delicious_id = get_option('padd_delicious_id');
                $delicious_url = "http://www.delicious.com/" . $delicious_id; 
		
                $digg_id = get_option('padd_digg_id');
                $digg_url = "http://digg.com/users/" . $digg_id;
				
				$facebook_id = get_option('padd_facebook_id');
                $facebook_url = "http://www.facebook.com/" . $facebook_id;

				$flickr_id = get_option('padd_flickr_id');
				$flickr_url = "http://www.flickr.com/people/" . $flickr_id;

				$linkedin_id = get_option('padd_linkedin_id');
				$linkedin_url = "http://www.linkedin.com/in/" . $linkedin_id;

                $stumbleupon_id = get_option('padd_stumbleupon_id');
                $stumbleupon_url = "http://" . $stumbleupon_id . ".stumbleupon.com/" ;
				                
	            $technorati_id = get_option('padd_technorati_id');
                $technorati_url = "http://technorati.com/people/technorati/" . $technorati_id;                 

				$twitter_id = get_option('padd_twitter_username');
                $twitter_url = "http://www.twitter.com/" . $twitter_id;
              
			
			?>
            
             <div id="socialbookmark">
                <div id="socialbookmark-wrapper">
                    <ul >
                        <li >
                        		<a href="<?php echo (!empty($delicious_id)) ? $delicious_url : '#'; ?>" class="bookmark" title="Delicious">
                                <img alt="Delicious Link" src="<?php echo get_bloginfo('template_url') . '/images/delicious-ico.png'; ?>" />
                                </a>
                        </li>
                        <li >
                        		<a href="<?php echo (!empty($digg_id)) ? $digg_url : '#'; ?>" class="bookmark" title="Digg">
                                <img alt="Digg Link" src="<?php echo get_bloginfo('template_url') . '/images/digg-ico.png'; ?>" />
                                </a>
                        </li>                            
                        <li>
                        		<a href="<?php echo (!empty($facebook_id)) ? $facebook_url : '#'; ?>" class="bookmark" title="Facebook">
                                <img alt="Facebook Link" src="<?php echo get_bloginfo('template_url') . '/images/fb-ico.png'; ?>" />
                                </a>
                        </li>
                        <li class="bookmark">
                        		<a href="<?php echo (!empty($flickr_id)) ? $flickr_url : '#'; ?>" class="bookmark" title="Flickr">
                                <img alt="Flickr Link" src="<?php echo get_bloginfo('template_url') . '/images/flickr-ico.png'; ?>" />
                                </a>
                        </li>
                        <li >
                        		<a href="<?php echo (!empty($linkedin_id)) ? $linkedin_url : '#'; ?>" class="bookmark" title="Linkedin">
                                <img alt="LinkedIn Link" src="<?php echo get_bloginfo('template_url') . '/images/linked-ico.png'; ?>" />
                                </a>
                        </li>                                  
						<li >
                        		<a href="<?php bloginfo('rss2_url'); ?>" class="bookmark" title="RSS Feeds">
                                <img alt="RSS Link" src="<?php echo get_bloginfo('template_url') . '/images/rss-ico.png'; ?>" />
                                </a>
                        </li>
                        <li >
                        		<a href="<?php echo (!empty($stumbleupon_id)) ? $stumbleupon_url : '#'; ?>" class="bookmark" title="StumbleUpon">
                                <img alt="StumbleUpon Link" src="<?php echo get_bloginfo('template_url') . '/images/su-ico.png'; ?>" />
                                 </a>
                        </li>
                        <li >
                        		<a href="<?php echo (!empty($technorati_id)) ? $technorati_url : '#'; ?>" class="bookmark" title="Technorati">
                                <img alt="RSS Link" src="<?php echo get_bloginfo('template_url') . '/images/techno-ico.png'; ?>" />
                                </a>
                        </li>                        
                        <li >
                        		<a href="<?php echo (!empty($twitter_id)) ? $twitter_url : '#'; ?>" class="bookmark" title="Twitter">
                                <img alt="Twitter Link" src="<?php echo get_bloginfo('template_url') . '/images/twit-ico.png'; ?>" />
                                </a>
                        </li>						
                    
                    </ul>
                </div>
            </div>  
          </div>     	
    </div>

	<div id="title">
		<div id="title-wrapper">
			<div id="sitename">
				<h1><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></h1>				
			</div>      
			<div id="search">
				<form id="searchform" method="get" action="<?php bloginfo('home'); ?>">
					<input type="text" name="s" id="s" size="25" value="Search the blog" />
				</form>				
			</div>
		</div>

	</div>
		<div id="category-wrapper">
        <div id="category">
        	<div id="category-menu">
                <ul>
                    <?php themefunction_category_menu(); ?>
                 </ul>
			</div>
        </div>
	  </div>
     
	<div id="wrapper">

		<div id="top-wrapper"></div>
		<div id="wrapper-wrapper">
			