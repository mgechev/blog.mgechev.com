Thank you for downloading Masunurin WordPress theme. Be sure you have downloaded the latest version of this theme at http://www.paddsolutions.com/wordpress-theme-masunurin

Installation
============
1. Extract masunurin.zip and upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress Admin Dashboard > Appearance > Themes and select the Masunurin screenshot.
3. Activate Masunurin WordPress Theme.

Required plugins and scripts
============================
1. Upload the tweetmeme and wp-pagenavi folders in the /wp-content/plugins directory.
2. Activate the plugins.

Support
========
If you have any problem or found some bugs upon using this WordPress theme, feel free to contact us at support@paddsolutions.com.

License Agreement
=================
This WordPress theme is Copyright 2009 by Padd Solutions. The CSS, XHTML and design is released under Creative Commons Attribution-Noncommercial-Share Alike 3.0 Unported: http://creativecommons.org/licenses/by-nc-sa/3.0/.
You are FREE to use the theme whether in original or modified form provided that the footer links at the bottom area are intact on every page.

Work Projects
==============
Padd Solutions are looking for new clients for Website Design and Development, get in touch with us at info@paddsolutions.com for your future projects.

