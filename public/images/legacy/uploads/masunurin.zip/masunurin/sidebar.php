<div id="sidebar">

	<div class="box box-adverts">
		<h2>Sponsors</h2>
		<div class="interior">
				<!-- Your ads start -->
				<?php
					$banner_img = get_option('padd_banner_250_img_url');
					$banner_url = get_option('padd_banner_250_web_url');
					$defaut_url = "http://www.paddsolutions.com";
					$default = get_bloginfo('template_url') . '/images/padd250x250.jpg';
				?>
				<p class="banner" >
					<a href="<?php echo (!empty($banner_url)) ? $banner_url : $defaut_url ; ?>" >
						<img alt="Advertisement" src="<?php echo (!empty($banner_img)) ? $banner_img : $default; ?>" />
					</a>
				</p>
				<!-- Your ads end -->
		
			<div class="row row-1">
				<?php
					$default = get_bloginfo('template_url') . '/images/padd125x125.png';
					$defaut_url = "http://www.paddsolutions.com";
					$sqbtn_1_img = get_option('padd_sqbtn_1_img_url');
					$sqbtn_1_url = get_option('padd_sqbtn_1_web_url');
					$sqbtn_2_img = get_option('padd_sqbtn_2_img_url');
					$sqbtn_2_url = get_option('padd_sqbtn_2_web_url');
				?>
				<a class="ads-1 ads-l" href="<?php echo (!empty($sqbtn_1_url)) ? $sqbtn_1_url : $defaut_url; ?>"><img alt="Advertisement" src="<?php echo (!empty($sqbtn_1_img)) ? $sqbtn_1_img : $default; ?>" /></a>
				<a class="ads-2 ads-r" href="<?php echo (!empty($sqbtn_2_url)) ? $sqbtn_2_url : $defaut_url; ?>"><img alt="Advertisement" src="<?php echo (!empty($sqbtn_2_img)) ? $sqbtn_2_img : $default; ?>" /></a>
			</div>
			<div class="row row-2">
				<?php
					$sqbtn_3_img = get_option('padd_sqbtn_3_img_url');
					$sqbtn_3_url = get_option('padd_sqbtn_3_web_url');
					$sqbtn_4_img = get_option('padd_sqbtn_4_img_url');
					$sqbtn_4_url = get_option('padd_sqbtn_4_web_url');
				?>
				<a class="ads-3 ads-l" href="<?php echo (!empty($sqbtn_3_url)) ? $sqbtn_3_url : $defaut_url; ?>"><img alt="Advertisement" src="<?php echo (!empty($sqbtn_3_img)) ? $sqbtn_3_img : $default; ?>" /></a>
				<a class="ads-4 ads-r" href="<?php echo (!empty($sqbtn_4_url)) ? $sqbtn_4_url : $defaut_url; ?>"><img alt="Advertisement" src="<?php echo (!empty($sqbtn_4_img)) ? $sqbtn_4_img : $default; ?>" /></a>
			</div>
		</div>
        <div class="bottom"> </div>
	</div>
    
    <?php 
		$twitter_username = get_option('padd_twitter_username');
		if (!empty($twitter_username)) {

	?>
	<div class="box box-twitter">
		<h2>Follow my <a href="http://twitter.com/<?php echo $twitter_username; ?>" title="Twitter">Tweets</a></h2>
		<div class="interior">
			<?php echo themefunction_twitter_get_recent_entries($twitter_username); ?>
		</div>
        <div class="bottom"> </div>
	</div>
	<?php 
		}
	?>
    
    
	<div class="box ">
		<h2>Featured Links</h2>
		<div class="interior">
        <ul>
			<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
		</ul>

		</div>
	 <div class="bottom"> </div>
	</div>
	
    	<div class="box">
        <h2>Recent Posts</h2>		
		<div class="interior">
        	<ul>
        		<?php wp_get_archives('title_li=&type=postbypost&limit=5'); ?>
            </ul>
		</div>
         <div class="bottom"> </div>
	</div>	
	
	
	<?php 
		$youtube_code = get_option('padd_youtube_code');
		if (!empty($youtube_code)) {
	?>
	<div class="box box-video">
		<h2>Featured Video</h2>
		<div class="interior">
			<?php echo stripslashes($youtube_code); ?>
			<div class="clearer"></div>
		</div>
         <div class="bottom"> </div>
	</div>
	<?php } ?>    
	<?php 
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Side Bar') ) { 
		
		 echo "<div class=\"bottom\"> </div>";
		}
	?>
	
</div>
