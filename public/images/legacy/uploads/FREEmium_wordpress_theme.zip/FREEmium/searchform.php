<form action="<?php echo get_option('home'); ?>/" id="searchform" method="get">
	<label for="s" class="hidden">Search for:</label>
	<div><input type="text" id="s" name="s" value=""/>
	<input type="submit" value="Search" id="searchsubmit"/> 
	</div>
</form>