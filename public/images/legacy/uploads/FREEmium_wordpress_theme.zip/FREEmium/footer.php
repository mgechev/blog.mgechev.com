			<div id="footer">
				<p>&copy; 2008 by <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> all rights reserved.</p>
				
				<p class="rss"><a href="<?php bloginfo('rss2_url'); ?>">subscribe via RSS</a></p>
			</div>
			
			<div id="powered">
				<p class="sponsor">
					<a href="http://www.blogperfume.com/category/wordpress-theme/" title="WordPress Themes">Wordpress Themes</a> sponsored by BlogPerfume
				</p>
				<p>
					<a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> is powered by <a href="http://wordpress.org/">WordPress</a> and <a href="http://www.freebiesdock.com/freemium-wordpress-theme/">FREEmium Theme</a>.<br /> developed by <a href="http://www.dariuszsiedlecki.com/">Dariusz Siedlecki</a> and brought to you by <a href="http://www.freebiesdock.com/">FreebiesDock.com</a>
				</p>
			</div>
		</div>
	</body>
</html>