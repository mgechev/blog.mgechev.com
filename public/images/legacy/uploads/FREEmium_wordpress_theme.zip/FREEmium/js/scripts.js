$(function() {
	$("#menu ul").lavaLamp({
		fx: "backout",
		speed: 700
    });
});